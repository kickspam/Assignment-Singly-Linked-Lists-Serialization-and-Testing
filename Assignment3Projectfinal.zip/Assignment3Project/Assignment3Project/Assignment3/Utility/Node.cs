﻿using Assignment3.ProblemDomain;
using System.Runtime.Serialization;

namespace Assignment3.Utility
{

    public class Node
    {
  
        public User Data { get; set; }


        public Node? Next { get; set; }

        public Node() { }

        public Node(User data)
        {
            Data = data;
            Next = null;
        }
    }
}
